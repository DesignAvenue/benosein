@extends('layouts.template')
@section('content')
    @include('partials.slider')
    @include('partials.under_slider')
    @include('partials.about_company')
    @include('partials.services')
    @include('partials.partners')
    

@endsection
